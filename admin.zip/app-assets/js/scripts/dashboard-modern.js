// Dashboard - Modern
//----------------------

;(function(window, document, $) {
  // //Sample toast
  /* setTimeout(function() {
    M.toast({ html: "Hey! I am a toast." })
  }, 2000)  */
})(window, document, jQuery)
